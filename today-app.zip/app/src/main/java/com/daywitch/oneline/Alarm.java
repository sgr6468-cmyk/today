package com.daywitch.oneline;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class Alarm {
    static final String CHANNEL = "daily";
    static final String ACTION = "com.daywitch.oneline.ALARM";

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("oneline", Context.MODE_PRIVATE);
    }

    static PendingIntent pending(Context c) {
        Intent i = new Intent(c, AlarmReceiver.class).setAction(ACTION);
        return PendingIntent.getBroadcast(c, 100, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    /** 저장된 시간으로 다음 알람 하나를 예약해요. 울리면 그다음 날 것을 다시 예약해요. */
    static void schedule(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        PendingIntent p = pending(c);
        am.cancel(p);

        String a = prefs(c).getString("alarm", "");
        if (a == null || !a.matches("\\d{1,2}:\\d{2}")) return;
        String[] hm = a.split(":");

        Calendar t = Calendar.getInstance();
        t.set(Calendar.HOUR_OF_DAY, Integer.parseInt(hm[0]));
        t.set(Calendar.MINUTE, Integer.parseInt(hm[1]));
        t.set(Calendar.SECOND, 0);
        t.set(Calendar.MILLISECOND, 0);
        if (t.getTimeInMillis() <= System.currentTimeMillis() + 1000) {
            t.add(Calendar.DAY_OF_MONTH, 1);
        }
        long at = t.getTimeInMillis();

        boolean exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms();
        try {
            if (exact) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p);
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p);
            }
        } catch (SecurityException e) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p);
        }
    }

    /** 일기장과 같은 규칙으로 '오늘' 날짜를 구해요 (하루가 바뀌는 시간 반영). */
    static String todayKey(Context c) {
        Calendar n = Calendar.getInstance();
        n.add(Calendar.HOUR_OF_DAY, -prefs(c).getInt("roll", 0));
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(n.getTime());
    }

    static void channel(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "저녁 알림",
                    NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("하루 한 줄을 남길 시간을 알려줘요");
            NotificationManager nm = c.getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }
}
