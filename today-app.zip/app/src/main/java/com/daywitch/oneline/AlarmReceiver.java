package com.daywitch.oneline;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent intent) {
        String act = intent.getAction();

        // 폰을 켰을 때, 앱을 업데이트했을 때는 알람만 다시 예약해요
        if (!Alarm.ACTION.equals(act)) {
            Alarm.schedule(c);
            return;
        }

        // 다음 날 알람 예약
        Alarm.schedule(c);

        // 오늘 이미 썼으면 알림을 건너뛰어요
        String done = Alarm.prefs(c).getString("done", "");
        if (Alarm.todayKey(c).equals(done)) return;

        if (Build.VERSION.SDK_INT >= 33
                && c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        Alarm.channel(c);
        Intent open = new Intent(c, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(c, Alarm.CHANNEL)
                : new Notification.Builder(c);
        b.setSmallIcon(R.drawable.ic_note)
                .setContentTitle("오늘한줄")
                .setContentText("오늘 한 줄 남길 시간이에요")
                .setAutoCancel(true)
                .setContentIntent(pi);

        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(1, b.build());
    }
}
