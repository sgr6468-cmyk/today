package com.daywitch.oneline;

import android.content.Context;
import android.webkit.JavascriptInterface;

/** 일기장 화면(웹)에서 부르는 기능이에요. window.Android 로 보여요. */
public class Bridge {
    private final Context ctx;

    Bridge(Context c) {
        ctx = c.getApplicationContext();
    }

    /** 알림 시간("21:00", 끄면 "")과 하루가 바뀌는 시간(roll)을 저장하고 알람을 다시 예약해요. */
    @JavascriptInterface
    public void setAlarm(String hhmm, int roll) {
        Alarm.prefs(ctx).edit()
                .putString("alarm", hhmm == null ? "" : hhmm)
                .putInt("roll", roll)
                .apply();
        Alarm.schedule(ctx);
    }

    /** 오늘 기록이 있으면 그 날짜를, 없으면 ""을 받아요. 이미 쓴 날은 알림을 건너뛰어요. */
    @JavascriptInterface
    public void setDone(String key) {
        Alarm.prefs(ctx).edit().putString("done", key == null ? "" : key).apply();
    }
}
